#compdef toli

_arguments -s \
  '--how[Get help on how to perform a task]' \
  '--do[Execute a task based on natural language description]' \
  '--explain[Explain what a given command does]' \
  '--alias[Suggest aliases for a given command]' \
  '--version[Show version information]'